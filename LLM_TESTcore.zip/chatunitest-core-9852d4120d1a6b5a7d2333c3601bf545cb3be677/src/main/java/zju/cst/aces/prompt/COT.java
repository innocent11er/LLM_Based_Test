package zju.cst.aces.prompt;

import java.util.List;

public class COT<T> {
    private List<T> depList;
    public void generate() {

    }
}
