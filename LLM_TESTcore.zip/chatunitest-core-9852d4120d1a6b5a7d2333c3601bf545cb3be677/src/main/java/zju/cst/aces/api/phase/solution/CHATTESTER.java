package zju.cst.aces.api.phase.solution;

import zju.cst.aces.api.config.Config;
import zju.cst.aces.api.phase.PhaseImpl;

public class CHATTESTER extends PhaseImpl {
    public CHATTESTER(Config config) {
        super(config);
    }
}
