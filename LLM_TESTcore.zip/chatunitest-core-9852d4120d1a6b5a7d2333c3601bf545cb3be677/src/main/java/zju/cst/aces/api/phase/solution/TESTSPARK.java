package zju.cst.aces.api.phase.solution;

import zju.cst.aces.api.config.Config;
import zju.cst.aces.api.phase.PhaseImpl;

public class TESTSPARK extends PhaseImpl {
    public TESTSPARK(Config config) {
        super(config);
    }
}
