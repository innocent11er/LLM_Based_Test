package zju.cst.aces.api;

public interface PreProcess {

    void process();

}
